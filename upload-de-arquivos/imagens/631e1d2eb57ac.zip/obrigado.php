<?php
echo "<h1>Obrigado. Tudo certo. Formulário enviado!</h1>";